/** Automatically generated file. DO NOT MODIFY */
package com.squareup.timessquare;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}